# Taiwan map workbench progress

Latest working tree: GitHub Pages repository in this directory, based on 390e9582a84e04ce43f2d32782936946815f292e. Do not restore earlier source over this working tree.

## Completed and checked before interruption
- Workbench restructuring; prediction-first entry, compact manual brushes, one legend editor, shared forecast data for numeric coloring, coordinated candidate lookup, toolbar menus and right-side prediction drawer.
- Council districts grouped within their county, all three identities included in lists and progress; geometry layers stay separate because identity boundaries overlap.
- Searchable/exportable reference tables for 221 council districts and 75 legislative districts; nationwide legislative indigenous seats remain two districts, three seats each.
- Complete boundary overlay geometry preserved.
- 32 calculation, migration and metadata checks passed. County council totals matched the uploaded August 20 announcement.
- Browser checks passed for Taipei's eight council districts, indigenous prediction entry, shared vote-to-color display, coordinated lookup and legislative reference table.

## In progress
Latest runtime asset revision: 20261029-workspace-v4.
- Offline root cause confirmed in browser: predictionUsesGradient referenced before workspace-ui.js loads. Embedded-map initialization now waits for DOMContentLoaded. Browser verified error panel hidden, all 22 map paths rendered, prediction drawer usable.
- Ballot sorting implemented centrally in directoryCandidates: positive integer ballot numbers ascending, unconfirmed numbers last, stable ties; IDs and original data untouched. Focused checks passed: all 447 district rosters retain their candidate IDs and are sorted numerically; browser shows Taipei mayor numbers 1–6.

## Pending
- Publication is authorized; browser GitHub upload session is signed in. No new permission question is required.
- Candidate CSV numeric order verified; PNG (2400×1980) and scheme JSON downloaded and parsed. SVG serialization exercised successfully by PNG export; direct SVG click shows success without browser download event. Attachment MIME experiment made no difference and was reverted; original SVG download behavior retained.
- Rebuild offline.html and source.zip from current sources, then publish to original GitHub Pages repository and verify deployed UI.
- Save final screenshot and record final deployed commit and check results here.

## Source locations
- Runtime source: this directory (flat GitHub Pages layout).
- Full source/package build: ../build-source (runtime files in dist/).
- Preview staging: ../preview-stage/dist/.
- User's district announcement: ../project_sources/01-1153150253-.pdf.
- Known preview route: use the exact URL returned by sites-preview start ../preview-stage.
- Terminal GitHub read works; write credentials were unavailable. Authenticated GitHub browser upload was available before interruption; no upload/commit had been performed.

## Decisions
- Preserve existing plans and local scenario data; no generated predictions ship with source.
- Keep cross-district reservation wording from the announcement; do not add it once per district.
- Legislative reference remains the 2024 geography; do not add 2026 local candidates as legislative candidates.
- Historical election module is reserved for later, not implemented in this task.

## Publication checkpoint
- Runtime revision: 20261029-workspace-v4.
- Published source commit: d858d6368d70ff582916a1a8a5c0fb01cfaba9d2.
- GitHub Pages run: 40906339854, awaiting final live verification.
- All 10 published files compared byte-for-byte with checked local sources.
- Remaining: confirm deployment completion, inspect live table and ballot order, save final screenshot.

## Final verification
- Pages deployment #27 completed successfully (31 seconds) for d858d6368d70ff582916a1a8a5c0fb01cfaba9d2.
- Live URL: https://alexwei2048.github.io/taiwan-map-painter/
- Live revision v4 confirmed, map error hidden, Taipei council dropdown and table both contain 8 districts.
- Live Taipei first district candidate rows verified in numeric order 1–20.
- Online SVG downloaded successfully and parsed as SVG; this resolves the earlier offline-browser download-event verification gap.
- Previously completed checks preserved; two new sorting checks passed. No user forecast values are included in deployed files.
- Remaining: final screenshot and handoff.

## Final task state
Completed: source edits, offline initialization repair, ballot sorting, original URL publication, live verification, screenshot.
In progress: none.
Pending: none for this request. Historical election module remains a separate future feature.
Latest verified runtime: 20261029-workspace-v4, public commit d858d6368d70ff582916a1a8a5c0fb01cfaba9d2.
Screenshot: /workspace/scratch/taiwan-map-workbench-live-1793289527691.jpg.
Next action: respond with the original live URL and concise change summary.

# 2026-10-30 township prediction extension
Completed baseline: published v4 (d858d63), preserve all prior changes.
In progress: mayor township winner/vote forecasts; council township vote forecasts; public ballot-number audit (325 pending across 13 office/county groups).
Design: separate local estimates from district winner choices; town ID plus district ID identifies council subarea, so split towns and indigenous electorates cannot mix candidate lists. Percentages do not auto-sum across towns; only complete local vote counts may be aggregated on explicit request.
Pending: local-data migration/CSV tests, browser QA, refreshed offline/source archive and publish.
Research sidecars write ballot-research-east.json and ballot-research-west.json outside runtime.

## Township extension implementation checkpoint
Completed: 221 council districts mapped to township subareas (split towns clipped only to relevant district); mayor local winners and candidate vote/share maps; council local votes/shares including indigenous districts; separate records and JSON migration; stable-ID CSV template/import/export; explicit full-vote aggregation preserving district winner decisions.
Completed ballot audit: 199 of 325 pending resolved; remaining126 (Changhua council1; township Kaohsiung6/Hsinchu1/Miaoli28/Nantou12/Pingtung62/Kinmen16). Two name conflicts retained pending. Source evidence and attempts preserved in source package; no guessed ballot slots or old-election numbers.
Validation:27 relevant automated checks passed. Browser: mayor vote-derived65.93% local lead, partial council candidate12%, JSON refresh display restoration, Hsinchu split scope, localCSV imported6 candidate rows then aggregation100–600 counts preserved with zero district winners, indigenous7-town district, offline feature initialization. Test data lives only in preview browser, never source.
Latest files:20261030-town-v5; baseline public commit d858d63 retained. In progress: regenerate source/offline artifacts and publish; pending: live deployment check and screenshot.
