# Taiwan map workbench progress

Latest working tree: GitHub Pages repository in this directory, based on 390e9582a84e04ce43f2d32782936946815f292e. Do not restore earlier source over this working tree.

## Completed and checked before interruption
- Workbench restructuring; prediction-first entry, compact manual brushes, one legend editor, shared forecast data for numeric coloring, coordinated candidate lookup, toolbar menus and right-side prediction drawer.
- Council districts grouped within their county, all three identities included in lists and progress; geometry layers stay separate because identity boundaries overlap.
- Searchable/exportable reference tables for 221 council districts and 75 legislative districts; nationwide legislative indigenous seats remain two districts, three seats each.
- Complete boundary overlay geometry preserved.
- 32 calculation, migration and metadata checks passed. County council totals matched the uploaded August 20 announcement.
- Browser checks passed for Taipei's eight council districts, indigenous prediction entry, shared vote-to-color display, coordinated lookup and legislative reference table.

## In progress
Latest runtime asset revision: 20261029-workspace-v4.
- Offline root cause confirmed in browser: predictionUsesGradient referenced before workspace-ui.js loads. Embedded-map initialization now waits for DOMContentLoaded. Browser verified error panel hidden, all 22 map paths rendered, prediction drawer usable.
- Ballot sorting implemented centrally in directoryCandidates: positive integer ballot numbers ascending, unconfirmed numbers last, stable ties; IDs and original data untouched. Focused checks passed: all 447 district rosters retain their candidate IDs and are sorted numerically; browser shows Taipei mayor numbers 1–6.

## Pending
- Publication is authorized; browser GitHub upload session is signed in. No new permission question is required.
- Candidate CSV numeric order verified; PNG (2400×1980) and scheme JSON downloaded and parsed. SVG serialization exercised successfully by PNG export; direct SVG click shows success without browser download event. Attachment MIME experiment made no difference and was reverted; original SVG download behavior retained.
- Rebuild offline.html and source.zip from current sources, then publish to original GitHub Pages repository and verify deployed UI.
- Save final screenshot and record final deployed commit and check results here.

## Source locations
- Runtime source: this directory (flat GitHub Pages layout).
- Full source/package build: ../build-source (runtime files in dist/).
- Preview staging: ../preview-stage/dist/.
- User's district announcement: ../project_sources/01-1153150253-.pdf.
- Known preview route: use the exact URL returned by sites-preview start ../preview-stage.
- Terminal GitHub read works; write credentials were unavailable. Authenticated GitHub browser upload was available before interruption; no upload/commit had been performed.

## Decisions
- Preserve existing plans and local scenario data; no generated predictions ship with source.
- Keep cross-district reservation wording from the announcement; do not add it once per district.
- Legislative reference remains the 2024 geography; do not add 2026 local candidates as legislative candidates.
- Historical election module is reserved for later, not implemented in this task.
