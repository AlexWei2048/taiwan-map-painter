"""Verify serialized election polygons, not just pre-export GEOS objects."""
import json,re
from pathlib import Path
from shapely.geometry import Polygon
from shapely import make_valid,unary_union
p=Path(__file__).parent;data=json.loads((p/'dist/assets/map.json').read_text())
def geom(f):
 g=Polygon()
 for ring in re.findall(r'M([^MZ]+)Z',f['d']):
  points=[tuple(map(float,q.split(','))) for q in ring.split('L')]
  if len(points)>=3:g=g.symmetric_difference(make_valid(Polygon(points)))
 return g
counties={f['name']:geom(f) for f in data['counties']}
for level,count in [('council',161),('legislative',73)]:
 assert len(data[level])==count
 for county,land in counties.items():
  gs=[geom(f) for f in data[level] if f['county']==county];cover=unary_union(gs)
  assert cover.symmetric_difference(land).area<.001,(level,county,'coverage')
  assert abs(sum(g.area for g in gs)-cover.area)<.001,(level,county,'overlap')
 assert len(data['districtBorders'][level])==22
villages=data['villages'];assert len(villages)==7731 and len({f['id'] for f in villages})==7731
assert all(re.fullmatch(r'\d{11}',f['id']) and f['name'] and f['townId'] for f in villages)
print('Serialized council/legislative geometry: 44 county coverage and overlap checks passed; 7,731 unique village IDs passed.')
