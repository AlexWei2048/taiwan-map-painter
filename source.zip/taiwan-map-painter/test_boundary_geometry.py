"""Verify serialized election polygons, not just pre-export GEOS objects."""
import json,re
from pathlib import Path
from shapely.geometry import Polygon
from shapely import make_valid,unary_union
p=Path(__file__).parent;data=json.loads((p/'dist/assets/map.json').read_text())
def geom(f):
 g=Polygon()
 for ring in re.findall(r'M([^MZ]+)Z',f['d']):
  points=[tuple(map(float,q.split(','))) for q in ring.split('L')]
  if len(points)>=3:g=g.symmetric_difference(make_valid(Polygon(points)))
 return g
counties={f['name']:geom(f) for f in data['counties']}
for level,count in [('council',161),('legislative',73)]:
 assert len(data[level])==count
 for county,land in counties.items():
  gs=[geom(f) for f in data[level] if f['county']==county];cover=unary_union(gs)
  assert cover.symmetric_difference(land).area<.001,(level,county,'coverage')
  assert abs(sum(g.area for g in gs)-cover.area)<.001,(level,county,'overlap')
 assert len(data['districtBorders'][level])==22
villages=data['villages'];assert len(villages)==7731 and len({f['id'] for f in villages})==7731
assert all(re.fullmatch(r'\d{11}',f['id']) and f['name'] and f['townId'] for f in villages)
print('Serialized council/legislative geometry: 44 county coverage and overlap checks passed; 7,731 unique village IDs passed.')
from shapely.geometry import Point,LineString

def lines(d):
 return unary_union([LineString([tuple(map(float,p.split(','))) for p in r.split('L')]) for r in re.findall(r'M([^MZ]+)',d) if 'L' in r])
for level in ['council','legislative']:
 for item in data['districtBorders'][level]:
  gs=[geom(f) for f in data[level] if f['county']==item['county']]
  shared=unary_union([a.boundary.intersection(b.boundary) for i,a in enumerate(gs) for b in gs[i+1:] if a.intersects(b)])
  mesh=lines(item['d']);land=counties[item['county']]
  assert mesh.difference(shared.buffer(.025)).length<.001,(level,item['county'],'unsupported residual stroke')
  expected=shared.difference(land.boundary.buffer(.02))
  assert expected.difference(mesh.buffer(.025)).length<.001,(level,item['county'],'missing real district edge')
for layer in ['counties','towns','villages','council','legislative']:
 for f in data[layer]:
  g=geom(f);point=Point(f['labelAnchor'])
  assert g.contains(point),(layer,f['id'],'leader outside')
  assert point.distance(g.boundary)>.0001,(layer,f['id'],'leader touches boundary')
assert all(len(data['townBorders'][key])==22 for key in ['all','council','legislative'])
print('All district strokes supported by shared district edges; no missing edges. All 8,355 interior anchors valid; township meshes present for 22 counties.')
