from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).parent
out=root/'dist/source.zip'
files=[root/n for n in ['LICENSE','README.md','THIRD_PARTY_NOTICES.md','prepare_map.py','package-source.py','prepare_elections.py','test-election-core.cjs','test-project-schema.cjs','test_boundary_geometry.py','build_party_logos.py','requirements-build.txt','build_candidate_directory.py','test-prediction-core.cjs','test-workspace.cjs','WORK_PROGRESS.md','build_town_prediction_areas.py','test-town-prediction.cjs','apply_ballot_audit.py','apply_wikipedia_ballots.py']]
files += [p for p in (root/'sources').rglob('*') if p.is_file()]
files += [p for p in (root/'dist').rglob('*') if p.is_file() and p!=out and not p.name.startswith('.source.zip.')]
with ZipFile(out,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,Path('taiwan-map-painter')/p.relative_to(root))
print('Source archive:',out.stat().st_size,'bytes;',len(files),'files')
