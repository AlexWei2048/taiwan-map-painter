from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).parent
out=root/'dist/source.zip'
files=[root/n for n in ['LICENSE','README.md','THIRD_PARTY_NOTICES.md','prepare_map.py','package-source.py','make-offline.py']]
files += [p for p in (root/'dist').rglob('*') if p.is_file() and p!=out]
with ZipFile(out,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,Path('taiwan-map-painter')/p.relative_to(root))
print('Source archive:',out.stat().st_size,'bytes;',len(files),'files')
