"""Build geographic council (2026) and legislative (2024) districts.

Run with the build dependencies on PYTHONPATH. Source documents are downloaded
explicitly by the maintainer; the published application has no network map API.
"""
from pathlib import Path
from collections import defaultdict, Counter
import csv, json, re, sys
from shapely.geometry import Polygon, MultiPolygon
from shapely.ops import unary_union
from shapely import make_valid
from opencc import OpenCC

ROOT = Path(__file__).parent
SOURCES = Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'sources'
cc = OpenCC('t2s')
simple = lambda s: cc.convert(s).replace('臺', '台').replace('巿', '市')
data = json.loads((ROOT/'dist/assets/map.json').read_text())
topo = json.loads((SOURCES/'villages-projected.json').read_text())
arcs = []
for arc in topo['arcs']:
    x = y = 0; out = []
    for dx,dy in arc:
        x += dx; y += dy
        out.append((x*topo['transform']['scale'][0]+topo['transform']['translate'][0],
                    y*topo['transform']['scale'][1]+topo['transform']['translate'][1]))
    arcs.append(out)

def ring(ids):
    out=[]
    for i in ids:
        a=arcs[i] if i>=0 else arcs[~i][::-1]
        out.extend(a if not out else a[1:])
    return out

def geometry(g):
    ps=[g['arcs']] if g['type']=='Polygon' else g['arcs']
    return make_valid(unary_union([Polygon(ring(p[0]),[ring(r) for r in p[1:]]) for p in ps]))

def svg_geometry(f):
    result=Polygon()
    for r in re.findall(r'M([^MZ]+)Z',f['d']):
        points=[tuple(map(float,p.split(','))) for p in r.split('L')]
        if len(points)>=3:
            result=result.symmetric_difference(make_valid(Polygon(points)))
    return make_valid(result)

towns={(f['county'],f['name']):(f,svg_geometry(f)) for f in data['towns']}
villages=[]
for g in topo['objects']['villages']['geometries']:
    p=g['properties']
    villages.append(dict(code=p['VILLCODE'],county=simple(p['COUNTYNAME']),
                         town=simple(p['TOWNNAME']),name=simple(p.get('VILLNAME','')),
                         geometry=geometry(g)))

def polygons(g):
    if isinstance(g,Polygon): return [g]
    return [p for sub in getattr(g,'geoms',[]) for p in polygons(sub)]

def feature(g,code,county,number,scope):
    ps=[p for p in polygons(g) if p.area>1e-7]
    assert ps,(code,'empty')
    g=unary_union(ps); anchor=max(ps,key=lambda p:p.area).representative_point()
    chunks=[]
    for p in ps:
        for r in [p.exterior,*p.interiors]:
            chunks.append('M'+'L'.join(f'{x:.2f},{y:.2f}' for x,y in r.coords)+'Z')
    return dict(id=code,county=county,name=f'第{number}选区',number=number,
                scope=scope,d=''.join(chunks),box=list(g.bounds),center=[anchor.x,anchor.y])

# CEC's current geographic council groups. Validate the three split towns at
# village level, then retain whole township geometry for every unsplit town.
rows=list(csv.DictReader((SOURCES/'council-zones.csv').open()))
vrows=list(csv.DictReader((SOURCES/'council-cunli.csv').open()))
assignment={r['village_code']:r['zone'] for r in vrows}
council_meta={r['code']:r for r in rows}
council_towns=defaultdict(list)
for r in rows:
    for town in r['areas'].split('/'):
        council_towns[(simple(r['city']),simple(town))].append(r['code'])

# Compare the split-village grouping to the official 2026 notice, independently
# of the third-party 2022-to-2026 mapping. These names are in that notice.
official_split={
 ('新竹县','竹北市','10004-01'):'尚义 崇义 新港 大义 白地 大眉 麻园 溪州 新庄 联兴 泰和 新社 新国 竹义 新仑',
 ('新竹市','东区','10018-02'):'南门 关帝 南市 福德 振兴 新兴 竹莲 南大 寺前 下竹 顶竹 光镇 高峰 柴桥 新光 湖滨 明湖',
 ('新竹市','北区','10018-03'):'客雅 中雅 育英 曲溪 西雅 南势 大鹏 西门 仁德 潜园 中央 崇礼 石坊 兴南 台溪',
}
for (county,town,zone),names in official_split.items():
    actual={v['name'].removesuffix('里') for v in villages
            if (v['county'],v['town'])==(county,town) and assignment.get(v['code'])==zone}
    assert actual==set(names.split()),(zone,actual^set(names.split()))

def partition(mapping, selector):
    groups=defaultdict(list); coverage={}
    for key,(f,land) in towns.items():
        zones=mapping.get(key,[])
        if not zones: raise ValueError(f'Unassigned township {key}')
        if len(zones)==1: groups[zones[0]].append(land);continue
        pieces=defaultdict(list)
        for v in villages:
            if (v['county'],v['town'])==key:
                zone=selector(v)
                assert zone in zones,(key,v['name'],zone,zones)
                pieces[zone].append(v['geometry'])
        # Fill an entire township exactly once, including small discrepancies
        # between the village-derived and township-derived coastlines.
        remaining=land
        for zone in zones[:-1]:
            part=make_valid(unary_union(pieces[zone])).intersection(remaining)
            groups[zone].append(part);remaining=remaining.difference(part)
        groups[zones[-1]].append(remaining)
    return {z:make_valid(unary_union(ps)) for z,ps in groups.items()}

council_geoms=partition(council_towns,lambda v:assignment.get(v['code']))
data['council']=[feature(council_geoms[z],z,simple(r['city']),int(z[-2:]),simple(r['areas']))
                 for z,r in council_meta.items()]
assert len(data['council'])==161

# Legislative selection is parsed from CEC's official CSV, not an old district
# geometry file. In particular, Zhongli's Ziqiang village belongs to district 6.
official=list(csv.DictReader((SOURCES/'legislative-2024.csv').open(encoding='utf-8-sig')))
leg_towns=defaultdict(list);leg_villages={};leg_meta={}
county_codes={f['name']:f['id'] for f in data['counties']}
for row in official:
    title=re.sub(r'\s','',simple(row['选举区'] if '选举区' in row else row['選舉區']))
    scope=re.sub(r'\s','',simple(row.get('選舉區範圍',row.get('选举区范围',''))))
    county=next(c for c in county_codes if title.startswith(c))
    found=re.search(r'第(\d+)',title);number=int(found[1]) if found else 1
    code=county_codes[county]+'-'+str(number).zfill(2)
    leg_meta[code]=(county,number,scope)
    if scope==county:
        for key in towns:
            if key[0]==county:leg_towns[key].append(code)
    elif '－' in scope:
        before,after=scope.split('－');parts=before.split('、')
        for town in parts[:-1]:leg_towns[(county,town)].append(code)
        town=parts[-1];leg_towns[(county,town)].append(code)
        names=re.sub(r'等\d+里$','',after).split('、')
        for name in names:
            key=(county,town,name)
            assert key not in leg_villages,(key,'duplicate')
            leg_villages[key]=code
    else:
        for town in scope.split('、'):leg_towns[(county,town)].append(code)

leg_geoms=partition(leg_towns,lambda v:leg_villages.get((v['county'],v['town'],v['name'])))
data['legislative']=[feature(leg_geoms[z],z,*m) for z,m in leg_meta.items()]
assert len(data['legislative'])==73
data['electionMetadata']={
 'council':{'year':2026,'count':161,'kind':'区域议员选区',
  'source':'https://www.cec.gov.tw/central/article/63625'},
 'legislative':{'year':2024,'count':73,'kind':'区域立委选区',
  'source':'https://data.gov.tw/dataset/170247'},
 'note':'原住民议员、原住民立委及不分区立委涉及重叠选民身份或政党名单，未混入区域选区图层。'
}
(ROOT/'dist/assets/map.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
print({k:len(data[k]) for k in ['counties','towns','council','legislative']})
