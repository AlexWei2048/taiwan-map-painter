import json
import re
from collections import Counter
from pathlib import Path
import pdfplumber

ROOT = Path('/workspace/scratch/8896632d6b9c')
P = ROOT / 'ballot-east-sources'
pending = [c for c in json.loads((ROOT / 'pending-ballots.json').read_text()) if c['county'] in ['彰化县', '花莲县', '连江县']]
configs = [
    ('changhua-council', 'council', 'https://web.cec.gov.tw/api/file/3fa6c5bc-efb9-4f5b-aff5-a6da35f2d8f3.pdf', '115年縣議員選舉候選人抽籤概況表'),
    ('changhua-township', 'township', 'https://web.cec.gov.tw/api/file/fc3216f9-62be-4a43-aea3-4747ce4f6d1b.pdf', '115年鄉鎮市長選舉候選人抽籤概況表'),
    ('hualien-council', 'council', 'https://web.cec.gov.tw/api/file/839b06dc-129a-42ac-9769-313458aa2a64.pdf', '[115年縣市議員選舉]候選人抽籤結果'),
    ('hualien-township', 'township', 'https://web.cec.gov.tw/api/file/806acf93-5675-4051-ab22-bf1d78ffec70.pdf', '[115年鄉鎮市長選舉]候選人抽籤結果'),
]
sources = []
rows = []
def compact(s):
    return re.sub(r'\s+', '', s or '')

for stem, typ, url, title in configs:
    sources.append(dict(url=url, title=title, localPath=str(P / (stem + '.pdf'))))
    with pdfplumber.open(P / (stem + '.pdf')) as pdf:
        for page_no, page in enumerate(pdf.pages, 1):
            for table in page.extract_tables():
                for cells in table:
                    if not cells[0] or not compact(cells[0]).startswith(('彰化縣', '花蓮縣')):
                        continue
                    district = compact(cells[0])
                    if stem == 'hualien-council':
                        num, name = cells[1], cells[2]
                    elif stem == 'hualien-township':
                        name, num = cells[1], cells[2]
                    else:
                        name, num = cells[1], cells[4]
                    assert num.isdigit(), cells
                    rows.append(dict(type=typ, district=district, name=name.replace('\n', ' '), number=int(num), sourceUrl=url, sourceTitle=title, page=page_no))

# Explicitly stated number/name pairs, never inferred from paragraph/list order.
matsu_url = 'https://www.nankan.gov.tw/Chhtml/Detail/2221?mcid=114026'
matsu_title = '支支好籤 四鄉順利完成候選人號次抽籤（南竿鄉公所轉載馬祖日報，2026-10-28）'
matsu_districts = {
    1: [(1, '曹丞君'), (2, '吳軾子'), (3, '陳書建'), (4, '林惠萍'), (5, '曹以標'), (6, '林明揚'), (7, '曹爾章')],
    2: [(1, '陳玉發'), (2, '周瑞國'), (3, '謝秉軒')],
    3: [(1, '陳貽斌'), (2, '王孝榛')],
    4: [(1, '馮印才'), (2, '林德建')],
}
for district, pairs in matsu_districts.items():
    for number, name in pairs:
        rows.append(dict(type='council', district=f'連江縣第{district}選舉區', name=name, number=number, sourceUrl=matsu_url, sourceTitle=matsu_title, page=None))
sources.extend([
    dict(url='https://web.cec.gov.tw/chec/article/65435', title='115年地方公職人員選舉候選人姓名號次抽籤概況表', localPath=str(P / 'chec-65435.html')),
    dict(url='https://web.cec.gov.tw/hlec/article/65438', title='115年花蓮縣地方公職人員選舉候選人姓名號次抽籤結果', localPath=str(P / 'hlec-65438.html')),
    dict(url=matsu_url, title=matsu_title),
    dict(url='https://www.matsu-news.gov.tw/news/article/245648', title='支支好籤 四鄉順利完成候選人號次抽籤（2026-10-28）'),
])

# District text uses simplified labels in the application's pending list.
district_chars = str.maketrans({'县':'縣','莲':'蓮','连':'連','选':'選','举':'舉','荣':'榮','区':'區','镇':'鎮','乡':'鄉','兴':'興','坛':'壇','园':'園','员':'員','盐':'鹽','头':'頭','凤':'鳳','复':'復','万':'萬'})
updates, unresolved = [], []
for c in pending:
    district = c['district'].translate(district_chars)
    names = {compact(c.get(k)) for k in ['name', 'nameOriginal']}
    names.add(compact(c.get('officialRegistrationSource', {}).get('name')))
    matches = [r for r in rows if r['type'] == c['type'] and r['district'] == district and compact(r['name']) in names]
    assert len(matches) <= 1, (c['id'], matches)
    if not matches:
        unresolved.append(c['id'])
        print('UNRESOLVED', c['id'], c['name'], district)
        continue
    r = matches[0]
    place = f"PDF第{r['page']}頁" if r['page'] else '2026-10-28正文；2026地方公職人員選舉、四鄉各節'
    evidence = f"{place}；選舉區：{r['district']}；姓名：{r['name']}；抽籤號次：{r['number']}。115年即2026年。"
    updates.append(dict(candidateId=c['id'], number=r['number'], sourceUrl=r['sourceUrl'], sourceTitle=r['sourceTitle'], evidence=evidence, year=2026))

by_id = {c['id']: c for c in pending}
keys = [(by_id[u['candidateId']]['districtId'], u['number']) for u in updates]
assert len(keys) == len(set(keys)), 'duplicate ballot numbers in district'
source_keys = [(r['type'], r['district'], r['number']) for r in rows]
assert len(source_keys) == len(set(source_keys)), 'duplicate numbers in source tables'
assert len(updates) + len(unresolved) == len(pending)
assert len({u['candidateId'] for u in updates}) == len(updates)
result = dict(updates=updates, unresolved=unresolved, sources=sources, notes=[
    '研究範圍僅彰化縣、花蓮縣、連江縣的pending-ballots.json未補號次候選人，共176人；連江縣待補名單無鄉長候選人。',
    '彰化縣選委會65435與花蓮縣選委會65438均於115年10月29日發布。附件以urllib下載成功，pdfplumber按表格欄位核對，pdftotext抽取，並目視檢查跨行姓名與花蓮第10選區；搜尋服務無法開啟這些新附件，但本機已下載並驗證PDF內容。',
    '連江縣選委會首頁未找到已發布號次表；連江14筆由南竿鄉公所2026-10-28轉載馬祖日報的四鄉號次報導直接核對，原始馬祖日報同文交叉核對。兩頁均由web open讀取全文；南竿頁urllib回503，故未附本機副本。',
    'council:10007:08:008 洪健興未補：彰化官方抽籤PDF第3頁第8選區列「洪建興」為9號，與待補名單及登記審定姓名「洪健興」不符。已目視確認建/健差異；未找到可證明兩者同一人的2026更正文件，嚴格不據此賦號。',
    '姓名匹配只移除空白/換行，亦採用輸入已核對的name及officialRegistrationSource.name；例如王昌智 Mac Lunai、蔡依靜 Lamen‧Panay。未模糊匹配不同漢字，未使用名單排序或舊屆選舉推定號次。',
    '所有更新year=2026，號次為正整數；已檢查每個選區內號次唯一，含完整官方來源表格中的其他候選人。未修改runtime或來源資料檔。',
])
(P / 'verified-table-rows.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
out = ROOT / 'ballot-research-east.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(out)
print('UPDATES', len(updates), 'UNRESOLVED', len(unresolved))
print(Counter((by_id[u['candidateId']]['county'], by_id[u['candidateId']]['type']) for u in updates))
