from pathlib import Path
from bs4 import BeautifulSoup
from opencc import OpenCC
import re,json,collections
root=Path(__file__).parent;r=root.parent/'taiwan-map-painter';s=(r/'assets/election-2026.js').read_text();db=json.loads(s.split('=',1)[1].rstrip(';\n'));cc=OpenCC('t2s');norm=lambda v:re.sub(r'\s+','',cc.convert(v)).replace('臺','台');districts={d['id']:d for d in db['districts']}
rows=[]
for typ in ['council','township']:
 soup=BeautifulSoup((root/(typ+'.html')).read_text(),'html.parser')
 for table in soup.select('table.wikitable'):
  header=table.find('tr');cols=[c.get_text('',strip=True) for c in header.find_all(['th','td'],recursive=False)]
  if '號次' not in cols or '候選人' not in cols:continue
  county=table.find_previous('h3').get_text('',strip=True);area=table.find_previous('h4').get_text('',strip=True)
  for tr in table.find_all('tr')[1:]:
   cells=tr.find_all(['td','th'],recursive=False)
   if len(cells)<4:continue
   number=cells[0].get_text('',strip=True);name=cells[1].get_text('',strip=True)
   rows.append(dict(type=typ,county=norm(county),area=area,name=name,number=int(number) if re.fullmatch(r'\d+',number) else None))
updates=[];pending=[];conflicts=[]
for c in db['candidates']:
 if c['type'] not in ['council','township']:continue
 d=districts[c['districtId']];names={norm(c.get(k,'')) for k in ['name','nameOriginal','officialName']};names.add(norm(c.get('officialRegistrationSource',{}).get('name','')));names.discard('')
 matches=[row for row in rows if row['type']==c['type'] and row['county']==c['county'] and norm(row['name']) in names and (c['type']=='council' or norm(row['area'])==norm(d['name'].replace(c['county'],'')) or norm(row['area'])==norm(d['name']))]
 # For council names that could recur, scope by the full county-wide heading district.
 if c['type']=='council':
  chinese=['零','一','二','三','四','五','六','七','八','九','十','十一','十二','十三','十四','十五','十六','十七','十八']
  number=int(c['districtId'].split(':')[-1]);matches=[x for x in matches if '第'+chinese[number]+'選舉區' in x['area']]
 if len(matches)==1 and matches[0]['number'] is not None:
  row=matches[0]
  if c['number']=='待补':updates.append({'candidateId':c['id'],'number':row['number'],'county':c['county'],'district':d['name'],'name':c['nameOriginal'],'area':row['area'],'wikiName':row['name'],'type':c['type']})
  elif c['number']!=row['number']:conflicts.append({'candidateId':c['id'],'current':c['number'],'wiki':row['number'],'name':c['nameOriginal'],'county':c['county'],'district':d['name']})
 elif c['number']=='待补':pending.append({**c,'reason':'网页对应候选人号次栏为空' if len(matches)==1 else '该网页未列此选区/候选人或不能唯一匹配','matchedRows':matches})
report={'updates':updates,'pending':pending,'conflicts':conflicts,'rows':rows};(root/'comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('Rows',len(rows),'updates',len(updates),'pending',len(pending),'existing conflicts',len(conflicts));print('updates',json.dumps(updates,ensure_ascii=False));print('pending',[(c['county'],c['district'],c['nameOriginal'],c['reason']) for c in pending]);print('conflicts',conflicts)
