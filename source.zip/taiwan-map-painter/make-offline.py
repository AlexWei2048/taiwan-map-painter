from pathlib import Path
import re
root=Path(__file__).parent;dist=root/'dist';s=(dist/'index.html').read_text()
s=re.sub(r'((?:href|src)="[^"<>]+)\?v=[^"<>]+"',r'\1"',s)
s=s.replace('<link href="style.css" rel="stylesheet"/>','<style>'+(dist/'style.css').read_text()+'</style>')
# Handle either HTML serialization order.
s=re.sub(r'<link[^>]*href="style.css"[^>]*>',lambda m:'<style>'+(dist/'style.css').read_text()+'</style>',s)
for f in re.findall(r'<script src="([^"]+)"></script>',s):
 content=(dist/f).read_text().replace('</script','<\\/script')
 prefix='<script id="embeddedMap" type="application/json">'+(dist/'assets/map.json').read_text().replace('<','\\u003c')+'</script>' if f=='app.js' else ''
 s=s.replace('<script src="'+f+'"></script>',prefix+'<script>'+content+'</script>')
s=re.sub(r'<a\b[^>]*class="[^"]*offline-download[^"]*"[^>]*>.*?</a>','',s)
s=s.replace('href="./"','href="#"')
(dist/'offline.html').write_text(s)
assert not re.search(r'<script[^>]+src=|<link[^>]+href="style.css',s)
print('Offline HTML:',(dist/'offline.html').stat().st_size)
