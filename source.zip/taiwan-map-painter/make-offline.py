from pathlib import Path
import re,json
root=Path(__file__).parent; dist=root/'dist';s=(dist/'index.html').read_text()
s=s.replace('<link rel="stylesheet" href="style.css">','<style>'+(dist/'style.css').read_text()+'</style>')
for file in ['assets/opencc.js','assets/parties.js']:
 s=s.replace('<script src="'+file+'"></script>','<script>'+(dist/file).read_text().replace('</script','<\\/script')+'</script>')
maptext=(dist/'assets/map.json').read_text().replace('<','\\u003c')
s=s.replace('<script src="app.js"></script>','<script id="embeddedMap" type="application/json">'+maptext+'</script><script>'+(dist/'app.js').read_text().replace('</script','<\\/script')+'</script>')
s=s.replace('<small>台湾地图填色</small>','<small>台湾地图填色 · 离线版</small>').replace('href="./"','href="#"')
s=re.sub(r'<a class="button quiet offline-download".*?</a>','',s)
s=re.sub(r'<div class="source-links">.*?</div>','<div class="source-links"><span>离线单文件版 · 无需联网</span></div>',s)
(dist/'offline.html').write_text(s)
print('Offline single HTML:',(dist/'offline.html').stat().st_size,'bytes')
